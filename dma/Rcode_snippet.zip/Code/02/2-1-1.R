data(weather, package="dmr.data")
data(weatherc, package="dmr.data"
data(weatherr, package="dmr.data")
