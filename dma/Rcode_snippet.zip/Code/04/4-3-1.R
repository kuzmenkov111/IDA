  # prior class probabilities for the weather data
pdisc(weather$play)
