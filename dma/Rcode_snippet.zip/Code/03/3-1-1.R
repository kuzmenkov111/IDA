library(dmr.claseval)
library(dmr.stats)
library(dmr.util)

library(rpart)
library(rpart.plot)
library(lattice)

data(weather, package="dmr.data")
data(weatherc, package="dmr.data")
