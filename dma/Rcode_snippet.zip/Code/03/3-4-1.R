rptree <- rpart(play~., weather, minsplit=2)
