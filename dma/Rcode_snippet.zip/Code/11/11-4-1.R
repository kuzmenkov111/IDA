discode(~., weathercl[1,])
discode(~., weathercl[5,])
