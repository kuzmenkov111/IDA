library(dmr.util)
library(dmr.trans)

data(weathercl, package="dmr.data")
