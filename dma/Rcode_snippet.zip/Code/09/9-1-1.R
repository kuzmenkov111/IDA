library(dmr.regeval)
library(dmr.stats)
library(dmr.util)

library(rpart)

data(weatherr, package="dmr.data")
