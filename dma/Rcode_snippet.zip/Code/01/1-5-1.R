weathercl <- weatherc[,-5]
