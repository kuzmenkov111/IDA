bs.mean <- function(v) { sum(v)/length(v) }


if (FALSE)
{

  # demonstration
bs.mean(weatherc$temperature)
mean(weatherc$temperature)

}
