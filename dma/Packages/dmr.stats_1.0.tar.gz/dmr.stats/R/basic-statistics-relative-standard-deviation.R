relsd <- function(v) { abs(varcoef(v)) }


if (FALSE)
{

  # demonstration
relsd(weatherr$playability)
relsd(-weatherr$playability)

}
