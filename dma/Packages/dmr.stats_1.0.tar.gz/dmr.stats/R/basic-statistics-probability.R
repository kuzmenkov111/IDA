prob <- function(v, v1) { sum(v==v1)/length(v) }


if (FALSE)
{

  # demonstration
prob(weather$outlook, "rainy")

}
