## L2 (Euclidean) vector norm
l2norm <- function(v) { sqrt(sum(v^2)) }


if (FALSE)
{

  # usage examples
l2norm(3:4)
l2norm(rep(3, 4))

}
