## p*log2(p) for p>=0
plogp <- function(p) { p*logp(p) }


if (FALSE)
{

  # usage examples
plogp(0)
plogp(1)
plogp(0.5)

}
