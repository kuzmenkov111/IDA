k.centers.init.rand <- function(data, k) { data[sample(1:nrow(data), k),] }
